#!/usr/bin/env python3
"""
ksc_install.py — только KSC для Wazuh: декодер, правила, приём syslog от KSC, (отдельный индекс — ksc-index-setup.sh).
Не зависит от комплекта MikroTik/СКУД и site.conf.

  sudo python3 ksc_install.py --source 10.50.50.48            установить (адрес, с которого приходит KSC; через запятую — несколько)
  sudo python3 ksc_install.py --source 172.21.1.6 --check     только проверить, ничего не менять
Параметры: --port 5515 (TCP), --rule-base 112000 (номера rule-base … rule-base+999), --no-remote (не трогать ossec.conf)
"""
import argparse, datetime, glob, ipaddress, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OSSEC = os.environ.get('OSSEC_DIR', '/var/ossec')
FILES = {'decoders': 'ksc_decoders.xml', 'rules': 'ksc_rules.xml'}
NAMES = {'kaspersky-ksc', 'kaspersky-ksc-fields'}
STAMP = datetime.datetime.now().strftime('%Y-%m-%d_%H%M%S')


def die(m):
    print('ОШИБКА: ' + m); sys.exit(1)


def renumber(text, new):
    def m(n):
        n = int(n)
        return str(n - 112000 + new) if 112000 <= n < 113000 else str(n)
    text = re.sub(r'(\bid=")(\d+)(")', lambda x: x.group(1) + m(x.group(2)) + x.group(3), text)
    return re.sub(r'(<if_(?:matched_)?sid>)([\d,\s]+)(</if_(?:matched_)?sid>)',
                  lambda x: x.group(1) + re.sub(r'\d+', lambda y: m(y.group(0)), x.group(2)) + x.group(3), text)


def restart():
    if os.environ.get('SKIP_RESTART'):
        print('(SKIP_RESTART: перезапуск пропущен)'); return
    subprocess.run(['systemctl', 'restart', 'wazuh-manager'], check=True)


def check(base):
    ok = True
    if not os.path.isdir(os.path.join(OSSEC, 'etc')):
        die('нет %s/etc — это сервер Wazuh?' % OSSEC)
    try:
        out = subprocess.run([os.path.join(OSSEC, 'bin', 'wazuh-control'), 'info'], capture_output=True, text=True, timeout=30).stdout
        v = re.search(r'WAZUH_VERSION="v?(\d+)\.(\d+)', out)
        if v:
            print('Wazuh %s.%s' % v.groups())
            if (int(v.group(1)), int(v.group(2))) < (4, 3):
                print('  ОШИБКА: нужен Wazuh 4.3+ (pcre2).'); ok = False
    except Exception:
        print('Версию Wazuh определить не удалось — продолжаю.')
    busy = {}
    for f in glob.glob(os.path.join(OSSEC, 'etc', 'rules', '*.xml')):
        if os.path.basename(f) == FILES['rules']:
            continue
        for n in re.findall(r'<rule\b[^>]*\bid="(\d+)"', open(f, encoding='utf-8', errors='replace').read()):
            if base <= int(n) <= base + 999:
                busy.setdefault(os.path.basename(f), []).append(n)
    if busy:
        ok = False
        print('  ОШИБКА: номера %d–%d заняты:' % (base, base + 999))
        for f, ns in busy.items():
            print('    %s: %s' % (f, ', '.join(ns[:10])))
        print('    Задайте другой --rule-base (например %d) или уберите старые правила.' % (base + 1000))
    else:
        print('Номера правил %d–%d свободны.' % (base, base + 999))
    clash = []
    for f in glob.glob(os.path.join(OSSEC, 'etc', 'decoders', '*.xml')) + glob.glob(os.path.join(OSSEC, 'ruleset', 'decoders', '*.xml')):
        if f.endswith(os.path.join('etc', 'decoders', FILES['decoders'])):
            continue
        if NAMES & set(re.findall(r'<decoder\b[^>]*\bname="([^"]+)"', open(f, encoding='utf-8', errors='replace').read())):
            clash.append(f)
    if clash:
        ok = False
        print('  ОШИБКА: декодер KSC уже есть в другом файле: ' + ', '.join(clash))
    else:
        print('Конфликтов имён декодеров нет.')
    return ok


def install(base):
    bk = os.path.join(OSSEC, 'etc', 'custom-backup-' + STAMP)
    done = []
    for kind, name in FILES.items():
        dst = os.path.join(OSSEC, 'etc', kind, name)
        b = None
        if os.path.exists(dst):
            os.makedirs(os.path.join(bk, kind), exist_ok=True)
            b = os.path.join(bk, kind, name); shutil.copy2(dst, b)
        data = open(os.path.join(HERE, name), encoding='utf-8').read()
        if kind == 'rules':
            data = renumber(data, base)
        open(dst, 'w', encoding='utf-8').write(data)
        try:
            shutil.chown(dst, 'wazuh', 'wazuh')
        except (LookupError, PermissionError):
            pass
        os.chmod(dst, 0o660)
        done.append((dst, b)); print('  ' + dst)
    r = subprocess.run([os.path.join(OSSEC, 'bin', 'wazuh-analysisd'), '-t'], capture_output=True, text=True)
    out = r.stdout + r.stderr
    if r.returncode != 0 or re.search(r'\b(ERROR|CRITICAL)\b', out):
        print(out[-3000:]); print('ОШИБКА конфигурации — возвращаю прежние файлы.')
        for dst, b in done:
            shutil.copy2(b, dst) if b else os.remove(dst)
        sys.exit(1)
    print('Декодер и правила KSC установлены, конфигурация в порядке.')


def remote(port, sources):
    conf = os.path.join(OSSEC, 'etc', 'ossec.conf')
    txt = open(conf, encoding='utf-8').read()
    found = None
    for m in re.finditer(r'<remote>.*?</remote>', txt, re.S):
        if re.search(r'<port>\s*%d\s*</port>' % port, m.group(0)):
            found = m; break
    if found:
        blk = found.group(0)
        if re.search(r'<connection>\s*secure', blk):
            die('порт %d занят приёмом агентов — укажите другой --port' % port)
        p = re.search(r'<protocol>\s*(\w+)', blk)
        if not p or p.group(1).lower() != 'tcp':
            die('порт %d в ossec.conf уже настроен не на TCP — исправьте вручную или укажите другой --port' % port)
        have = set(re.findall(r'<allowed-ips>\s*([^<\s]+)\s*</allowed-ips>', blk))
        add = [s for s in sources if s not in have]
        if not add:
            print('Приём на %d/TCP уже настроен, адреса разрешены.' % port); return False
        ind = (re.search(r'\n(\s*)<port>', blk) or re.search(r'(  )', blk)).group(1)
        new = re.sub(r'(\s*)</remote>$', lambda mm: ''.join('\n%s<allowed-ips>%s</allowed-ips>' % (ind, s) for s in add) + mm.group(0), blk)
        txt = txt[:found.start()] + new + txt[found.end():]
        what = 'добавлены адреса ' + ', '.join(add)
    else:
        block = ('  <!-- Kaspersky Security Center: Syslog RFC 5424 (ksc_install) -->\n  <remote>\n    <connection>syslog</connection>\n'
                 '    <port>%d</port>\n    <protocol>tcp</protocol>\n%s  </remote>\n\n') % (port, ''.join('    <allowed-ips>%s</allowed-ips>\n' % s for s in sources))
        i = txt.find('</ossec_config>')
        if i < 0:
            die('в ossec.conf нет </ossec_config>')
        txt = txt[:i] + block + txt[i:]
        what = 'новый блок, адреса ' + ', '.join(sources)
    bk = conf + '.bak-' + STAMP
    shutil.copy2(conf, bk)
    open(conf, 'w', encoding='utf-8').write(txt)
    rt = os.path.join(OSSEC, 'bin', 'wazuh-remoted')
    if os.path.exists(rt):
        r = subprocess.run([rt, '-t'], capture_output=True, text=True)
        if r.returncode != 0:
            shutil.copy2(bk, conf)
            die('wazuh-remoted -t не прошёл, ossec.conf возвращён:\n' + (r.stdout + r.stderr)[-2000:])
    print('ossec.conf: порт %d/TCP — %s (копия %s)' % (port, what, bk))
    return True


def main():
    ap = argparse.ArgumentParser(description='KSC для Wazuh')
    ap.add_argument('--source', default='', help='адрес(а), с которых приходят события KSC (IP сервера KSC или NAT перед ним), через запятую')
    ap.add_argument('--port', type=int, default=5515)
    ap.add_argument('--rule-base', type=int, default=112000)
    ap.add_argument('--no-remote', action='store_true', help='не трогать ossec.conf')
    ap.add_argument('--check', action='store_true', help='только проверить')
    a = ap.parse_args()
    if os.geteuid() != 0 and not os.environ.get('OSSEC_DIR'):
        die('запустите через sudo')
    if a.rule_base < 100000:
        die('--rule-base от 100000')
    src = [s for s in re.split(r'[,\s]+', a.source) if s]
    for s in src:
        try:
            ipaddress.ip_network(s, strict=False)
        except ValueError:
            die('«%s» — не IP-адрес' % s)
    if not src and not a.no_remote and not a.check:
        die('укажите --source <IP KSC или NAT-адрес> (узнать: sudo tcpdump -i any -nn port %d и «Test settings» в KSC) или --no-remote' % a.port)
    if not check(a.rule_base):
        die('проверка не пройдена — ничего не изменено.')
    if a.check:
        return
    print('Устанавливаю:')
    install(a.rule_base)
    if not a.no_remote:
        remote(a.port, src)
    restart()
    print('wazuh-manager перезапущен. Дальше: sudo bash ksc-index-setup.sh (отдельный индекс), затем «Test settings» в KSC.')


if __name__ == '__main__':
    main()
