#!/usr/bin/env bash
#
# ksc-index-setup.sh — отдельный индекс для событий Kaspersky Security Center в Wazuh.
#
# Алерты с группой правила "ksc" (ksc_rules.xml) пишутся не в wazuh-alerts-4.x-YYYY.MM.DD,
# а в wazuh-alerts-4.x-ksc-YYYY.MM.DD. Остальные алерты Wazuh — как раньше.
# Имя подпадает под wazuh-alerts-4.x-*, поэтому шаблон полей Wazuh применяется сам,
# а wazuh-index-cleanup.sh удаляет эти индексы через 90 дней без изменений.
#
# Что делает:
#   1) проверяет, что новое имя покрыто шаблоном индексов "wazuh" (если нет — добавляет);
#   2) правит конвейер Filebeat (pipeline.json модуля wazuh/alerts): выбирает префикс индекса по rule.groups;
#   3) загружает конвейер в индексер и перезапускает filebeat.
# Перед правкой делает копии файлов (*.bak-<дата>). Запускать повторно можно: изменения не дублируются.
# ВАЖНО: обновление Wazuh/Filebeat перезаписывает pipeline.json и шаблон — после обновления запустить скрипт снова.
#
# Использование:  sudo ./ksc-index-setup.sh
#
set -euo pipefail

PREFIX="${PREFIX:-wazuh-alerts-4.x-ksc-}"
GROUP="${GROUP:-ksc}"
INDEXER_URL="${INDEXER_URL:-https://localhost:9200}"
PIPE="${PIPE:-/usr/share/filebeat/module/wazuh/alerts/ingest/pipeline.json}"
TPL="${TPL:-/etc/filebeat/wazuh-template.json}"
CRED_FILE="${CRED_FILE:-/root/.wazuh-indexer.cred}"          # user:password, chmod 600
ADMIN_CERT="${ADMIN_CERT:-/etc/wazuh-indexer/certs/admin.pem}"
ADMIN_KEY="${ADMIN_KEY:-/etc/wazuh-indexer/certs/admin-key.pem}"

[[ $EUID -eq 0 ]] || { echo "Запустите через sudo"; exit 1; }
for f in "$PIPE" "$TPL"; do [[ -f "$f" ]] || { echo "Нет файла $f"; exit 1; }; done

# Вход в индексер: файл с учётными данными или сертификат admin
if [[ -r "$CRED_FILE" ]]; then AUTH=(-u "$(head -n1 "$CRED_FILE")")
elif [[ -r "$ADMIN_CERT" && -r "$ADMIN_KEY" ]]; then AUTH=(--cert "$ADMIN_CERT" --key "$ADMIN_KEY")
else echo "Нет $CRED_FILE и сертификата $ADMIN_CERT — нечем войти в индексер"; exit 1; fi
api() { curl -sS -k --max-time 60 "${AUTH[@]}" "$@"; }

api "$INDEXER_URL/_cluster/health" | grep -q '"status"' || { echo "Индексер недоступен по $INDEXER_URL"; exit 1; }
api "$INDEXER_URL/_template/wazuh" | grep -q '"index_patterns"' || { echo "В индексере нет шаблона 'wazuh'"; exit 1; }

TS="$(date +%F_%H%M%S)"
cp -a "$PIPE" "$PIPE.bak-$TS"
cp -a "$TPL"  "$TPL.bak-$TS"
echo "Копии: $PIPE.bak-$TS, $TPL.bak-$TS"

# ---------- 1. Шаблон ----------
python3 - "$TPL" "$PREFIX" <<'PY'
import json, sys, fnmatch
path, prefix = sys.argv[1], sys.argv[2]
t = json.load(open(path, encoding='utf-8'))
pats = t.setdefault('index_patterns', [])
covered = [p for p in pats if fnmatch.fnmatch(prefix + '2026.01.01', p)]
if covered:
    print('Шаблон: %s* уже покрыт шаблоном %s — изменений не нужно' % (prefix, covered[0]))
else:
    pats.append(prefix + '*')
    json.dump(t, open(path, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)
    print('Шаблон: добавлен %s*' % prefix)
PY
resp="$(api -X PUT "$INDEXER_URL/_template/wazuh" -H 'Content-Type: application/json' -d @"$TPL")"
[[ "$resp" == *'"acknowledged":true'* ]] || { echo "Ошибка загрузки шаблона: $resp"; exit 1; }
echo "Шаблон загружен в индексер"

# ---------- 2. Конвейер ----------
python3 - "$PIPE" "$PREFIX" "$GROUP" <<'PY'
import json, sys
path, prefix, group = sys.argv[1:4]
d = json.load(open(path, encoding='utf-8'))
procs = d['processors']
def tag(p):
    v = next(iter(p.values()))
    return v.get('tag', '') if isinstance(v, dict) else ''
orig = None
for p in procs:                                   # повторный запуск: исходный префикс сохранён в нашем процессоре
    if tag(p) == 'ksc-index-default':
        orig = p['set']['value']
procs = [p for p in procs if not tag(p).startswith('ksc-index')]
i = next(i for i, p in enumerate(procs) if 'date_index_name' in p)
din = procs[i]['date_index_name']
if orig is None:
    orig = din.get('index_name_prefix')
if not orig or orig == '{{wazuh_index_prefix}}':
    sys.exit('Не найден исходный index_name_prefix в date_index_name — восстановите pipeline.json из копии')
din['index_name_prefix'] = '{{wazuh_index_prefix}}'
cond = "ctx.rule instanceof Map && ctx.rule.groups instanceof List && ctx.rule.groups.contains('%s')" % group
procs[i:i] = [
    {'set': {'tag': 'ksc-index-default', 'field': 'wazuh_index_prefix', 'value': orig}},
    {'set': {'tag': 'ksc-index-route', 'if': cond, 'field': 'wazuh_index_prefix', 'value': prefix}},
]
procs.insert(i + 3, {'remove': {'tag': 'ksc-index-cleanup', 'field': 'wazuh_index_prefix', 'ignore_missing': True}})
d['processors'] = procs
json.dump(d, open(path, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)
print('Конвейер: алерты с группой "%s" -> %sYYYY.MM.DD, остальные -> %s' % (group, prefix, orig))
PY

# ---------- 3. Загрузка и перезапуск ----------
filebeat setup --pipelines >/dev/null
api "$INDEXER_URL/_ingest/pipeline/filebeat-*-wazuh-alerts-pipeline" | grep -q 'ksc-index-route' \
  || { echo "Конвейер в индексере не обновился — проверьте: filebeat setup --pipelines -e"; exit 1; }
echo "Конвейер загружен в индексер"
systemctl restart filebeat
sleep 3
filebeat test output >/dev/null && echo "Filebeat перезапущен, связь с индексером есть"

echo
echo "Готово. Нажмите «Test settings» в KSC и проверьте через минуту:"
echo "  curl -k -u \"\$(sudo head -1 $CRED_FILE)\" '$INDEXER_URL/_cat/indices/${PREFIX}*?v'"
echo "Откат: верните файлы из копий *.bak-$TS, затем filebeat setup --pipelines и systemctl restart filebeat"
