#!/usr/bin/env bash
# Установка KSC в Wazuh одной командой:
#   sudo bash install.sh <IP KSC или NAT-адрес>[,<ещё>]   — декодер, правила, приём 5515/TCP, отдельный индекс
# Доп. параметры передаются в ksc_install.py, например: sudo bash install.sh 10.50.50.48 --rule-base 113000
set -euo pipefail
cd "$(dirname "$0")"
[[ $EUID -eq 0 ]] || { echo "Запустите через sudo"; exit 1; }
[[ $# -ge 1 ]] || { echo "Использование: sudo bash install.sh <IP, с которого приходит KSC> [--rule-base N] [--port N]"; exit 1; }
SRC="$1"; shift
python3 ksc_install.py --source "$SRC" "$@"
bash ksc-index-setup.sh
